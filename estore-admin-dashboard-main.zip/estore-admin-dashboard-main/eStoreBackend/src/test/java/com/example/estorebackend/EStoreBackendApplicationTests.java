package com.example.estorebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EStoreBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}

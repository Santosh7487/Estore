export class OrderItems {
  orderItemId: any;
  orderId: any;
  productId: any;
  productTitle: any;
  productDescription: any;
  productCode: any;
  productImg: any;
  productCategory: any;
  price: any;
  quantity: any;
  totalPrice: any;
}

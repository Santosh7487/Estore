export class Shipments {
  shipmentId: any;
  orderId: any;
  shipmentStatus: any;
  shipmentTitle: any;
  shipmentDate: any;
  shipmentMethod: any;
  shipmentCompany: any;
  expectedDeliveryDate: any;
}

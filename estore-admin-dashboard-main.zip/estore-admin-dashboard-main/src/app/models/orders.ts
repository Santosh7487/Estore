export class Orders {
  orderId: any;
  orderDate: any;
  orderStatus: any;
  totalItems: any;
  itemsSubTotal: any;
  shipmentCharges: any;
  totalAmount: any;
  paymentStatus: any;
  paymentStatusTitle: any;
  paymentMethod: any;
  paymentMethodTitle: any;
  userId: any;
  name: any;
  email: any;
  contact: any;
  address: any;
  products: any[] = [];
}

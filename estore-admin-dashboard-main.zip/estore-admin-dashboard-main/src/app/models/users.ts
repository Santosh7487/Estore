export class Users {
  userId: any;
  email: any;
  password: any;
  fullName: any;
  street: any;
  city: any;
  state: any;
  country: any;
  pincode: any;
  image: any;
  contact: any;
  addedOn: any;
}

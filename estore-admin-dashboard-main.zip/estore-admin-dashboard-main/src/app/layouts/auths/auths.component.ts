import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auths',
  templateUrl: './auths.component.html',
  styleUrls: ['./auths.component.css']
})
export class AuthsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
